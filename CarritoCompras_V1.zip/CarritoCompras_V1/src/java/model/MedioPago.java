package model;

public class MedioPago {
    private Usuario usuario;
    private String numeroTarjeta;
    private String nombreTitular;
    private String mesVenc;
    private String anioVenc;
    private int codSeguridad;

    public MedioPago(Usuario usuario, String numeroTarjeta, String nombreTitular, String mesVenc, String anioVenc, int codSeguridad) {
        this.usuario = usuario;
        this.numeroTarjeta = numeroTarjeta;
        this.nombreTitular = nombreTitular;
        this.mesVenc = mesVenc;
        this.anioVenc = anioVenc;
        this.codSeguridad = codSeguridad;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }

    public String getNombreTitular() {
        return nombreTitular;
    }

    public void setNombreTitular(String nombreTitular) {
        this.nombreTitular = nombreTitular;
    }

    public String getMesVenc() {
        return mesVenc;
    }

    public void setMesVenc(String mesVenc) {
        this.mesVenc = mesVenc;
    }

    public String getAnioVenc() {
        return anioVenc;
    }

    public void setAnioVenc(String anioVenc) {
        this.anioVenc = anioVenc;
    }

    public int getCodSeguridad() {
        return codSeguridad;
    }

    public void setCodSeguridad(int codSeguridad) {
        this.codSeguridad = codSeguridad;
    }
    
    
}
