//CAPA DE REGLAS DE NEGOCIO
package RN;
//capa entre el modelo y el controlador, para ver la logica de negocio
public class CarritoRN {
    
}
